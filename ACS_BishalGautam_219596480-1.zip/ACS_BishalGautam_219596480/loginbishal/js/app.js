
var x = document.getElementById("passField");
x.addEventListener("keyup", function () {
  validate(x.value);
});


x.addEventListener("focus", function () {
  RemoveClass("password-policies", "hide");
});


x.addEventListener("blur", function () {
  AddClass("password-policies", "hide");
});

function validate(pswd) {
  if (pswd.length >= 8) {
    valid("length");
  } else {
    invalid("length");
  }

  if (pswd.match(/[0-9]/)) {
    valid("number");
  } else {
    invalid("number");
  }

  if (pswd.match(/[A-Z]/)) {
    valid("upperCase"); 
  } else {
    invalid("upperCase");
  }

  if (pswd.match(/[!\@\#\$\%\^\&\*\(\)\_\-\+\=\?\>\<\.\,]/)) {
    valid("specialCharacter");
  } else {
    invalid("specialCharacter");
  }
}
/* password icon color change*/
function valid(id) {
  AddClass(id, "valid");
  RemoveClass(id, "invalid");
  AddClassOnIcon(id, "fa-check");
  RemoveClassOnIcon(id, "fa-times");
}
function invalid(id) {
  AddClass(id, "invalid");
  RemoveClass(id, "valid");
  AddClassOnIcon(id, "fa-times");
  RemoveClassOnIcon(id, "fa-check");
}

function AddClass(id, cl) {
  document.getElementById(id).classList.add(cl);
}
function RemoveClass(id, cl) {
  document.getElementById(id).classList.remove(cl);
}
function AddClassOnIcon(id, cl) {
  document.getElementById(id).firstElementChild.classList.add(cl);
}
function RemoveClassOnIcon(id, cl) {
  document.getElementById(id).firstElementChild.classList.remove(cl);
}

// Password strength indicator
function getPasswordStrength(password){
  let s = 0;
  if(password.length > 6){
    s++;
  }
  if(/[!\@\#\$\%\^\&\*\(\)\_\-\+\=\?\>\<\.\,]/.test(password)){
    s++;
  }
  if(/[A-Z]/.test(password)){
    s++;
  }
  if(/[0-9]/.test(password)){
    s++;
  }
  if(/[^A-Za-z0-9]/.test(password)){
    s++;
  }
  return s;
}

// password strength
document.querySelector("form #passField").addEventListener("focus",function(){
  document.querySelector("form .pw-strength").style.display = "block";
});

document.querySelector("form #passField").addEventListener("keyup",function(e){
  let password = e.target.value;
  let strength = getPasswordStrength(password);
  let passwordStrengthSpans = document.querySelectorAll("form .pw-strength span");
  strength = Math.max(strength,1);
  passwordStrengthSpans[1].style.width = strength*20 + "%";
  if(strength < 2){
    passwordStrengthSpans[0].innerText = "Weak";
    passwordStrengthSpans[0].style.color = "#111";
    passwordStrengthSpans[1].style.background = "#d13636";
  } else if(strength >= 2 && strength <= 4){
    passwordStrengthSpans[0].innerText = "Medium";
    passwordStrengthSpans[0].style.color = "#111";
    passwordStrengthSpans[1].style.background = "#e6da44";
  } else {
    passwordStrengthSpans[0].innerText = "Strong";
    passwordStrengthSpans[0].style.color = "#fff";
    passwordStrengthSpans[1].style.background = "#20a820";
  }
});

// close password strength indicator when clicked elsewhere
document.querySelector("form #passField").addEventListener("blur",function(){
  document.querySelector("form .pw-strength").style.display = "none";
});
